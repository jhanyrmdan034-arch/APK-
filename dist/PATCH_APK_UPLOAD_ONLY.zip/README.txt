PATCH: APK upload fix (2026-11-18)

این ۳ فایل را در /home/nexsrvr آپلود و Extract کن (Overwrite بزن):
  public_html/admin/delivery_builder.php
  public_html/admin/apk.php
  private/security/helpers.php

بعد: chmod 0775 private/apk private/logs
سپس Ctrl+F5 و تست آپلود APK.
