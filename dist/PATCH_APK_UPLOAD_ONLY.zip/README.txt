PATCH APK UPLOAD — 2026-11-18

در /home/USERNAME آپلود و Extract کن (Overwrite):
  public_html/admin/delivery_builder.php
  public_html/admin/apk.php
  public_html/admin/apk_upload.php   <-- جدید: آپلود تکه‌تکه
  public_html/assets/apk-upload.js   <-- جدید
  private/security/helpers.php

سپس: chmod 0775 private/apk private/logs private/uploads
و private/uploads/incoming را بساز (0775) اگر نبود.
