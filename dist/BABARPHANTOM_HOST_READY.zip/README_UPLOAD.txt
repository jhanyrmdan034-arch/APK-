آپلود و نصب فوری — فقط 2 مرحله
1. این ZIP را در File Manager -> Home (/home/nexsrvr) آپلود و Extract کن
2. برو https://yourdomain.com/install.php و فرم دیتابیس را پر کن — تمام!
   نصاب خودش جدول‌ها را می‌سازد و config.php را می‌سازد.
