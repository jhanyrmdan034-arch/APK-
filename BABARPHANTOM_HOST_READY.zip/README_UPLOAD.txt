آپلود و نصب فوری — بدون Move
1. برو cPanel -> File Manager
2. بزن "Home" یا تا بالا برو تا ببینی پوشه های adpulse_private , public_html , etc
   یعنی مسیر /home/nexsrvr رو ببینی
3. بزن Upload -> این ZIP رو انتخاب کن (BABARPHANTOM_HOST_READY.zip)
4. بعد از 100% بزن Go Back -> روی ZIP کلیک کن -> Extract -> Extract File(s)
5. تمومه! خودکار میره سر جاش:
   - public_html/admin , public_html/api ... آپدیت میشه
   - private/ میاد کنار public_html
6. بعد برو phpMyAdmin و 3 تا SQL رو Import کن (اگر قبلا نکردی)
7. برو private/config/config.sample.php رو کپی به config.php و پر کن
