این زیپ را در Home هاست (/home/USERNAME) آپلود و Extract کن — ساختار public_html و private خودکار ساخته می‌شود.
سپس https://دامنه/install.php را باز کن.
